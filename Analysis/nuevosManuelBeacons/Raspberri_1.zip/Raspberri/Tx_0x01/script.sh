#!/bin/bash
./a.out <p1
./a.out <p2
./a.out <p3
./a.out <p4
./a.out <p5
./a.out <p6
./a.out <p7
./a.out <p8
./a.out <p9
./a.out <p10
./a.out <p11
./a.out <p12
./a.out <p13
./a.out <p14
./a.out <p15
